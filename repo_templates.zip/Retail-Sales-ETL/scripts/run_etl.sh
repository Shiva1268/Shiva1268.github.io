#!/bin/bash
echo 'Run ETL scripts'