# Retail Sales ETL

Instructions to run ADF and Databricks pipeline locally using sample data.