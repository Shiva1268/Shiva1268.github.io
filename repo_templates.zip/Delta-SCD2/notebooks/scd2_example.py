from pyspark.sql.functions import sha2, concat_ws
# sample code here