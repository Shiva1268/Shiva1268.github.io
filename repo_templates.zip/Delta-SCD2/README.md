# Delta SCD2

Contains MERGE sample and unit tests.