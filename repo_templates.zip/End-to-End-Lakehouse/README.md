# End-to-End Lakehouse (Template)

## Overview
This repo contains sample notebooks and deployment scripts for building a simple lakehouse on Azure.

## Structure
- /notebooks : Databricks notebooks (PySpark)
- /infrastructure : ARM templates or Terraform
- /sample-data : Example CSV/JSON files
- /deploy.sh : helper script to deploy notebooks to Databricks