# Sample PySpark notebook
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()
df = spark.read.csv("sample-data/sales.csv", header=True, inferSchema=True)
df.show(5)
